<div class="wrapper col5">
  <div id="footer">

    <div id="copyright">
      
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>