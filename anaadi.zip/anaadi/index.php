<?php
include("header.php");
?>
<div class="wrapper col1">
  <div id="container">
    <div id="content">
      <h1>Welcome to Anaadi foundation</h1>
      
    

      <div class="homecontent">
        <ul>
          <li>
            <h2>Book your Appointment through online   </h2>
            <p class="imgholder"><a href="patientappointment.php"><img src="images/appointment.png" alt="" style="width:286px;height:100px;" /></a></p>
          </li>
          <li class="last">
            <h2>Login Panel for existing users</h2>          
            <p class="imgholder"><a href="patientlogin.php"><img src="images/login.jpg" alt="" style="width:286px;height:100px;"  /></a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
    </div>
   
    <div class="clear"></div>
  </div>
</div>
<?php
include("footer.php");
?>