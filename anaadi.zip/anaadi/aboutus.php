<?php
include("header.php");
?>
<div class="wrapper col2">
  
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>About anaadi foundation</h1>
   
      
           
     
   
<?php
include("footer.php");
?>